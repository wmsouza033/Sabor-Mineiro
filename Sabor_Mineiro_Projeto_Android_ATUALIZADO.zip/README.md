# Sabor Mineiro — Projeto Android

Este pacote contém a versão atual do aplicativo Sabor Mineiro e a configuração para empacotá-la como aplicativo Android.

## Dados do aplicativo
- Nome: Sabor Mineiro
- ID Android: com.sabormineiro.gerenciador
- Slogan: Entregando Qualidade e Sabor.
- Conteúdo: clientes, mercadorias, pedidos, vendas, pagamentos, contas a receber e relatórios.

## Compilação
O projeto usa Capacitor. Em um ambiente Android/Node com acesso à internet:
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. Abrir a pasta `android` no Android Studio e gerar o APK.

Também pode ser usado em um serviço de build Android na nuvem compatível com projetos Node/Gradle.

## Observação
O banco atual do protótipo usa armazenamento local do navegador/WebView. Antes de uso comercial definitivo, é recomendável migrar os dados para um banco persistente.
